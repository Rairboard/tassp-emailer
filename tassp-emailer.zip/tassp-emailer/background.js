const ALL_REPS = [
  { district: 1,   name: "VanDeaver, Gary",                    url: "https://house.texas.gov/members/2540/email" },
  { district: 2,   name: "Money, Brent",                       url: "https://house.texas.gov/members/4670/email" },
  { district: 3,   name: "Bell Jr., Cecil",                    url: "https://house.texas.gov/members/2335/email" },
  { district: 4,   name: "Bell, Keith",                        url: "https://house.texas.gov/members/3695/email" },
  { district: 5,   name: "Hefner, Cole",                       url: "https://house.texas.gov/members/3505/email" },
  { district: 6,   name: "Alders, Daniel",                     url: "https://house.texas.gov/members/4395/email" },
  { district: 7,   name: "Dean, Jay",                          url: "https://house.texas.gov/members/3515/email" },
  { district: 8,   name: "Harris, Cody",                       url: "https://house.texas.gov/members/3580/email" },
  { district: 9,   name: "Ashby, Trent",                       url: "https://house.texas.gov/members/2330/email" },
  { district: 10,  name: "Harrison, Brian",                    url: "https://house.texas.gov/members/4085/email" },
  { district: 11,  name: "Shofner, Joanne",                    url: "https://house.texas.gov/members/4755/email" },
  { district: 12,  name: "Wharton, Trey",                      url: "https://house.texas.gov/members/4795/email" },
  { district: 13,  name: "Orr, Angelia",                       url: "https://house.texas.gov/members/4340/email" },
  { district: 14,  name: "Dyson, Paul",                        url: "https://house.texas.gov/members/4475/email" },
  { district: 15,  name: "Toth, Steve",                        url: "https://house.texas.gov/members/2825/email" },
  { district: 16,  name: "Metcalf, Will",                      url: "https://house.texas.gov/members/2900/email" },
  { district: 17,  name: "Gerdes, Stan",                       url: "https://house.texas.gov/members/4195/email" },
  { district: 18,  name: "Holt, Janis",                        url: "https://house.texas.gov/members/4535/email" },
  { district: 19,  name: "Troxclair, Ellen",                   url: "https://house.texas.gov/members/4385/email" },
  { district: 20,  name: "Wilson, Terry M.",                   url: "https://house.texas.gov/members/3525/email" },
  { district: 21,  name: "Phelan, Dade",                       url: "https://house.texas.gov/members/2905/email" },
  { district: 22,  name: "Manuel, Christian",                  url: "https://house.texas.gov/members/4255/email" },
  { district: 23,  name: "Leo Wilson, Terri",                  url: "https://house.texas.gov/members/4290/email" },
  { district: 24,  name: "Bonnen, Greg",                       url: "https://house.texas.gov/members/2875/email" },
  { district: 25,  name: "Vasut, Cody",                        url: "https://house.texas.gov/members/4065/email" },
  { district: 26,  name: "Morgan, Matt",                       url: "https://house.texas.gov/members/4675/email" },
  { district: 27,  name: "Reynolds, Ron",                      url: "https://house.texas.gov/members/2040/email" },
  { district: 28,  name: "Gates, Gary",                        url: "https://house.texas.gov/members/3920/email" },
  { district: 29,  name: "Barry, Jeff",                        url: "https://house.texas.gov/members/4405/email" },
  { district: 30,  name: "Louderback, AJ",                     url: "https://house.texas.gov/members/4620/email" },
  { district: 31,  name: "Guillen, Ryan",                      url: "https://house.texas.gov/members/3045/email" },
  { district: 32,  name: "Hunter, Todd",                       url: "https://house.texas.gov/members/3365/email" },
  { district: 33,  name: "Pierson, Katrina",                   url: "https://house.texas.gov/members/4715/email" },
  { district: 34,  name: "Villalobos, Denise",                 url: "https://house.texas.gov/members/4770/email" },
  { district: 35,  name: "Longoria, Oscar",                    url: "https://house.texas.gov/members/2485/email" },
  { district: 36,  name: "Muñoz Jr., Sergio",                  url: "https://house.texas.gov/members/2060/email" },
  { district: 37,  name: "Lopez, Janie",                       url: "https://house.texas.gov/members/4295/email" },
  { district: 38,  name: "Gámez, Erin",                        url: "https://house.texas.gov/members/4095/email" },
  { district: 39,  name: "Martinez, Armando",                  url: "https://house.texas.gov/members/3780/email" },
  { district: 40,  name: "Canales, Terry",                     url: "https://house.texas.gov/members/2340/email" },
  { district: 41,  name: "Guerra, R.D. Bobby",                 url: "https://house.texas.gov/members/2325/email" },
  { district: 42,  name: "Raymond, Richard Peña",              url: "https://house.texas.gov/members/4215/email" },
  { district: 43,  name: "Lozano, J. M.",                      url: "https://house.texas.gov/members/2065/email" },
  { district: 44,  name: "Schoolcraft, Alan",                  url: "https://house.texas.gov/members/4745/email" },
  { district: 45,  name: "Zwiener, Erin",                      url: "https://house.texas.gov/members/3710/email" },
  { district: 46,  name: "Cole, Sheryl",                       url: "https://house.texas.gov/members/3625/email" },
  { district: 47,  name: "Goodwin, Vikki",                     url: "https://house.texas.gov/members/3820/email" },
  { district: 48,  name: "Howard, Donna",                      url: "https://house.texas.gov/members/3310/email" },
  { district: 49,  name: "Hinojosa, Gina",                     url: "https://house.texas.gov/members/3210/email" },
  { district: 50,  name: "Talarico, James",                    url: "https://house.texas.gov/members/3685/email" },
  { district: 51,  name: "Flores, Lulu",                       url: "https://house.texas.gov/members/4150/email" },
  { district: 52,  name: "Harris Davila, Caroline",            url: "https://house.texas.gov/members/4205/email" },
  { district: 53,  name: "Virdell, Wes",                       url: "https://house.texas.gov/members/4775/email" },
  { district: 54,  name: "Buckley, Brad",                      url: "https://house.texas.gov/members/3585/email" },
  { district: 55,  name: "Hickland, Hillary",                  url: "https://house.texas.gov/members/4520/email" },
  { district: 56,  name: "Curry, Pat",                         url: "https://house.texas.gov/members/4415/email" },
  { district: 57,  name: "Hayes, Richard",                     url: "https://house.texas.gov/members/4165/email" },
  { district: 58,  name: "Kerwin, Helen",                      url: "https://house.texas.gov/members/4575/email" },
  { district: 59,  name: "Slawson, Shelby",                    url: "https://house.texas.gov/members/4055/email" },
  { district: 60,  name: "Olcott, Mike",                       url: "https://house.texas.gov/members/4705/email" },
  { district: 61,  name: "Richardson, Keresa",                 url: "https://house.texas.gov/members/4735/email" },
  { district: 62,  name: "Luther, Shelley",                    url: "https://house.texas.gov/members/4645/email" },
  { district: 63,  name: "Bumgarner, Benjamin",                url: "https://house.texas.gov/members/4125/email" },
  { district: 64,  name: "Hopper, Andy",                       url: "https://house.texas.gov/members/4555/email" },
  { district: 65,  name: "Little, Mitch",                      url: "https://house.texas.gov/members/4615/email" },
  { district: 66,  name: "Shaheen, Matt",                      url: "https://house.texas.gov/members/2995/email" },
  { district: 67,  name: "Leach, Jeff",                        url: "https://house.texas.gov/members/2475/email" },
  { district: 68,  name: "Spiller, David",                     url: "https://house.texas.gov/members/4075/email" },
  { district: 69,  name: "Frank, James",                       url: "https://house.texas.gov/members/2385/email" },
  { district: 70,  name: "Plesa, Mihaela",                     url: "https://house.texas.gov/members/4345/email" },
  { district: 71,  name: "Lambert, Stan",                      url: "https://house.texas.gov/members/3225/email" },
  { district: 72,  name: "Darby, Drew",                        url: "https://house.texas.gov/members/2645/email" },
  { district: 73,  name: "Isaac, Carrie",                      url: "https://house.texas.gov/members/4265/email" },
  { district: 74,  name: "Morales, Eddie",                     url: "https://house.texas.gov/members/4000/email" },
  { district: 75,  name: "González, Mary E.",                  url: "https://house.texas.gov/members/2410/email" },
  { district: 76,  name: "Lalani, Suleman",                    url: "https://house.texas.gov/members/4285/email" },
  { district: 77,  name: "Perez, Vincent",                     url: "https://house.texas.gov/members/4710/email" },
  { district: 78,  name: "Moody, Joe",                         url: "https://house.texas.gov/members/3850/email" },
  { district: 79,  name: "Ordaz, Claudia",                     url: "https://house.texas.gov/members/4015/email" },
  { district: 80,  name: "McLaughlin, Don",                    url: "https://house.texas.gov/members/4655/email" },
  { district: 81,  name: "Landgraf, Brooks",                   url: "https://house.texas.gov/members/3040/email" },
  { district: 82,  name: "Craddick, Tom",                      url: "https://house.texas.gov/members/2610/email" },
  { district: 83,  name: "Burrows, Dustin",                    url: "https://house.texas.gov/members/3055/email" },
  { district: 84,  name: "Tepper, Carl H.",                    url: "https://house.texas.gov/members/4360/email" },
  { district: 85,  name: "Kitzman, Stan",                      url: "https://house.texas.gov/members/4280/email" },
  { district: 86,  name: "Smithee, John T.",                   url: "https://house.texas.gov/members/4530/email" },
  { district: 87,  name: "Fairly, Caroline",                   url: "https://house.texas.gov/members/4480/email" },
  { district: 88,  name: "King, Ken",                          url: "https://house.texas.gov/members/2455/email" },
  { district: 89,  name: "Noble, Candy",                       url: "https://house.texas.gov/members/3740/email" },
  { district: 90,  name: "Romero Jr., Ramon",                  url: "https://house.texas.gov/members/3060/email" },
  { district: 91,  name: "Lowe, David",                        url: "https://house.texas.gov/members/4643/email" },
  { district: 92,  name: "Bhojani, Salman",                    url: "https://house.texas.gov/members/4115/email" },
  { district: 93,  name: "Schatzline, Nate",                   url: "https://house.texas.gov/members/4355/email" },
  { district: 94,  name: "Tinderholt, Tony",                   url: "https://house.texas.gov/members/3065/email" },
  { district: 95,  name: "Collier, Nicole",                    url: "https://house.texas.gov/members/2360/email" },
  { district: 96,  name: "Cook, David",                        url: "https://house.texas.gov/members/3960/email" },
  { district: 97,  name: "McQueeney, John",                    url: "https://house.texas.gov/members/4665/email" },
  { district: 98,  name: "Capriglione, Giovanni",              url: "https://house.texas.gov/members/2345/email" },
  { district: 99,  name: "Geren, Charlie",                     url: "https://house.texas.gov/members/2945/email" },
  { district: 100, name: "Jones, Venton",                      url: "https://house.texas.gov/members/4275/email" },
  { district: 101, name: "Turner, Chris",                      url: "https://house.texas.gov/members/4680/email" },
  { district: 102, name: "Rodríguez Ramos, Ana-María",         url: "https://house.texas.gov/members/3735/email" },
  { district: 103, name: "Anchía, Rafael",                     url: "https://house.texas.gov/members/2150/email" },
  { district: 104, name: "González, Jessica",                  url: "https://house.texas.gov/members/3335/email" },
  { district: 105, name: "Meza, Terry",                        url: "https://house.texas.gov/members/3455/email" },
  { district: 106, name: "Patterson, Jared",                   url: "https://house.texas.gov/members/3655/email" },
  { district: 107, name: "Garcia, Linda",                      url: "https://house.texas.gov/members/4485/email" },
  { district: 108, name: "Meyer, Morgan",                      url: "https://house.texas.gov/members/3075/email" },
  { district: 109, name: "Davis, Aicha",                       url: "https://house.texas.gov/members/4465/email" },
  { district: 110, name: "Rose, Toni",                         url: "https://house.texas.gov/members/2555/email" },
  { district: 111, name: "Davis, Yvonne",                      url: "https://house.texas.gov/members/2625/email" },
  { district: 112, name: "Button, Angie Chen",                 url: "https://house.texas.gov/members/2510/email" },
  { district: 113, name: "Bowers, Rhetta Andrews",             url: "https://house.texas.gov/members/3565/email" },
  { district: 114, name: "Bryant, John",                       url: "https://house.texas.gov/members/4120/email" },
  { district: 115, name: "Garcia Hernandez, Cassandra",        url: "https://house.texas.gov/members/4495/email" },
  { district: 116, name: "Martinez Fischer, Trey",             url: "https://house.texas.gov/members/2835/email" },
  { district: 117, name: "Cortez, Philip",                     url: "https://house.texas.gov/members/2365/email" },
  { district: 118, name: "Lujan, John",                        url: "https://house.texas.gov/members/3145/email" },
  { district: 119, name: "Campos, Elizabeth",                  url: "https://house.texas.gov/members/3950/email" },
  { district: 120, name: "Gervin-Hawkins, Barbara",            url: "https://house.texas.gov/members/3445/email" },
  { district: 121, name: "LaHood, Marc",                       url: "https://house.texas.gov/members/4595/email" },
  { district: 122, name: "Dorazio, Mark",                      url: "https://house.texas.gov/members/4145/email" },
  { district: 123, name: "Bernal, Diego M.",                   url: "https://house.texas.gov/members/3110/email" },
  { district: 124, name: "Garcia, Josey",                      url: "https://house.texas.gov/members/4170/email" },
  { district: 125, name: "Lopez, Ray",                         url: "https://house.texas.gov/members/3915/email" },
  { district: 126, name: "Harless, Sam",                       url: "https://house.texas.gov/members/3775/email" },
  { district: 127, name: "Cunningham, Charles",                url: "https://house.texas.gov/members/4130/email" },
  { district: 128, name: "Cain, Briscoe",                      url: "https://house.texas.gov/members/3265/email" },
  { district: 129, name: "Paul, Dennis",                       url: "https://house.texas.gov/members/3090/email" },
  { district: 130, name: "Oliverson, Tom",                     url: "https://house.texas.gov/members/3535/email" },
  { district: 131, name: "Allen, Alma A.",                     url: "https://house.texas.gov/members/2100/email" },
  { district: 132, name: "Schofield, Mike",                    url: "https://house.texas.gov/members/3095/email" },
  { district: 133, name: "DeAyala, Mano",                      url: "https://house.texas.gov/members/4135/email" },
  { district: 134, name: "Johnson, Ann",                       url: "https://house.texas.gov/members/3985/email" },
  { district: 135, name: "Rosenthal, Jon E.",                  url: "https://house.texas.gov/members/3635/email" },
  { district: 136, name: "Bucy lll, John H.",                  url: "https://house.texas.gov/members/3595/email" },
  { district: 137, name: "Wu, Gene",                           url: "https://house.texas.gov/members/2865/email" },
  { district: 138, name: "Hull, Lacey",                        url: "https://house.texas.gov/members/3975/email" },
  { district: 139, name: "Ward Johnson, Charlene",             url: "https://house.texas.gov/members/4785/email" },
  { district: 140, name: "Walle, Armando",                     url: "https://house.texas.gov/members/4930/email" },
  { district: 141, name: "Thompson, Senfronia",                url: "https://house.texas.gov/members/4630/email" },
  { district: 142, name: "Dutton Jr., Harold V.",              url: "https://house.texas.gov/members/2650/email" },
  { district: 143, name: "Hernandez, Ana",                     url: "https://house.texas.gov/members/3155/email" },
  { district: 144, name: "Perez, Mary Ann",                    url: "https://house.texas.gov/members/2535/email" },
  { district: 145, name: "Morales, Christina",                 url: "https://house.texas.gov/members/3910/email" },
  { district: 146, name: "Simmons, Lauren Ashley",             url: "https://house.texas.gov/members/4765/email" },
  { district: 147, name: "Jones, Jolanda",                     url: "https://house.texas.gov/members/4105/email" },
  { district: 148, name: "Morales Shaw, Penny",                url: "https://house.texas.gov/members/4035/email" },
  { district: 149, name: "Vo, Hubert",                         url: "https://house.texas.gov/members/4900/email" },
  { district: 150, name: "Swanson, Valoree",                   url: "https://house.texas.gov/members/3425/email" },
];

chrome.storage.local.set({ allReps: ALL_REPS });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // ── Popup starts a campaign ───────────────────────────────────────────────
  if (msg.action === "startCampaign") {
    const { userData, queue } = msg;
    chrome.storage.local.set(
      { queue, currentIndex: 0, userData, running: true, completed: [], failed: [] },
      () => openNext(sender.tab)
    );
    sendResponse({ ok: true });
  }

  // ── Content script signals that the page is ready ─────────────────────────
  if (msg.action === "pageReady") {
    chrome.storage.local.get(["queue", "currentIndex", "userData", "running"], (data) => {
      if (!data.running) { sendResponse(null); return; }
      sendResponse({ rep: data.queue[data.currentIndex], userData: data.userData });
    });
    return true; // async
  }

  // ── User submitted the form; advance to next rep ──────────────────────────
  if (msg.action === "formDone") {
    chrome.storage.local.get(["queue", "currentIndex", "completed", "failed", "lastAdvancedIndex"], (data) => {
      // Guard: ignore if this district was already advanced (e.g. both /process and /thankyou fire)
      if (data.lastAdvancedIndex === data.currentIndex) {
        sendResponse({ ok: true, skipped: true });
        return;
      }
      const rep       = data.queue[data.currentIndex];
      const completed = [...(data.completed || [])];
      const failed    = [...(data.failed    || [])];

      if (msg.success) completed.push(rep.district);
      else             failed.push(rep.district);

      const nextIndex = data.currentIndex + 1;

      chrome.storage.local.set({ currentIndex: nextIndex, completed, failed, lastAdvancedIndex: data.currentIndex }, () => {
        if (nextIndex < data.queue.length) {
          // The formDone message is sent from the /email/thankyou page,
          // which means the submission is already confirmed. Navigate immediately.
          chrome.tabs.update(sender.tab.id, { url: data.queue[nextIndex].url });
        } else {
          // All done
          chrome.storage.local.set({ running: false });
        }
      });
    });
    sendResponse({ ok: true });
  }

  // ── Stop campaign ─────────────────────────────────────────────────────────
  // ── /email/process hit — navigate back to same rep's email form ──────────
  if (msg.action === "retryRep") {
    chrome.storage.local.get(["queue", "currentIndex", "running"], (data) => {
      if (!data.running) return;
      const rep = data.queue[data.currentIndex];
      if (rep) {
        console.log(`[TASSP] /process hit for District ${rep.district} — retrying same rep.`);
        chrome.tabs.update(sender.tab.id, { url: rep.url });
      }
    });
    sendResponse({ ok: true });
  }

  if (msg.action === "stopCampaign") {
    chrome.storage.local.set({ running: false });
    sendResponse({ ok: true });
  }

  // ── Popup polls for status ─────────────────────────────────────────────────
  if (msg.action === "getStatus") {
    chrome.storage.local.get(["queue", "currentIndex", "running", "completed", "failed"], (data) => {
      sendResponse(data);
    });
    return true; // async
  }
});

function openNext(senderTab) {
  chrome.storage.local.get(["queue", "currentIndex", "running"], (data) => {
    if (!data.running || data.currentIndex >= data.queue.length) return;
    const rep = data.queue[data.currentIndex];
    // Reuse the tab that sent the message if available, otherwise use the active tab
    if (senderTab && senderTab.id) {
      chrome.tabs.update(senderTab.id, { url: rep.url });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) chrome.tabs.update(tabs[0].id, { url: rep.url });
        else chrome.tabs.create({ url: rep.url });
      });
    }
  });
}
