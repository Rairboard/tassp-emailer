const fields = ["fname","lname","email","address","city","zip","phone","subject","message"];

// Wire up buttons and placeholder chips via addEventListener (CSP-safe)
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("startBtn").addEventListener("click", startCampaign);
  document.getElementById("stopBtn").addEventListener("click", stopCampaign);

  document.querySelectorAll("#placeholderRow span").forEach((span) => {
    span.addEventListener("click", () => ins(span.dataset.tag));
  });
});

// Restore saved values
chrome.storage.local.get(["userData"], (data) => {
  if (data.userData) {
    const u = data.userData;
    document.getElementById("fname").value    = u.fname    || "";
    document.getElementById("lname").value    = u.lname    || "";
    document.getElementById("email").value    = u.email    || "";
    document.getElementById("address").value  = u.address  || "";
    document.getElementById("city").value     = u.city     || "";
    document.getElementById("zip").value      = u.zip      || "";
    document.getElementById("phone").value    = u.phone    || "";
    document.getElementById("subject").value  = u.subject  || "";
    document.getElementById("message").value  = u.msgTemplate || "";
  }
});

// Check if a campaign is already running and update UI
chrome.runtime.sendMessage({ action: "getStatus" }, (data) => {
  if (data && data.running) {
    showRunning(data);
    pollStatus();
  }
});

function getUserData() {
  return {
    fname:       document.getElementById("fname").value.trim(),
    lname:       document.getElementById("lname").value.trim(),
    email:       document.getElementById("email").value.trim(),
    address:     document.getElementById("address").value.trim(),
    city:        document.getElementById("city").value.trim(),
    zip:         document.getElementById("zip").value.trim(),
    phone:       document.getElementById("phone").value.trim(),
    subject:     document.getElementById("subject").value.trim(),
    msgTemplate: document.getElementById("message").value
  };
}

function startCampaign() {
  const userData = getUserData();
  if (!userData.fname || !userData.lname || !userData.email) {
    alert("Please fill in at least your first name, last name, and email.");
    return;
  }

  // Save for next time
  chrome.storage.local.set({ userData });

  chrome.storage.local.get(["allReps"], (data) => {
    const queue = data.allReps || [];
    chrome.runtime.sendMessage({ action: "startCampaign", userData, queue }, () => {
      showRunning({ queue, currentIndex: 0, completed: [], failed: [] });
      pollStatus();
    });
  });
}

function stopCampaign() {
  chrome.runtime.sendMessage({ action: "stopCampaign" }, () => {
    document.getElementById("startBtn").disabled = false;
    document.getElementById("stopBtn").classList.remove("visible");
    document.getElementById("statusText").textContent = "Stopped.";
  });
}

function showRunning(data) {
  document.getElementById("statusBar").classList.add("visible");
  document.getElementById("startBtn").disabled = true;
  document.getElementById("stopBtn").classList.add("visible");
  document.getElementById("completeMsg").classList.remove("visible");
  updateProgress(data);
}

function updateProgress(data) {
  const total = (data.queue || []).length;
  const idx   = data.currentIndex || 0;
  const ok    = (data.completed || []).length;
  const fail  = (data.failed || []).length;
  const pct   = total ? Math.round((idx / total) * 100) : 0;

  document.getElementById("progressFill").style.width = pct + "%";
  document.getElementById("progressNum").textContent  = idx + " / " + total;
  document.getElementById("statusText").textContent   = "Waiting — District " + (idx + 1);
  document.getElementById("countOk").textContent      = ok + " sent";
  document.getElementById("countFail").textContent    = fail + " failed";
}

let pollTimer = null;
function pollStatus() {
  pollTimer = setInterval(() => {
    chrome.runtime.sendMessage({ action: "getStatus" }, (data) => {
      if (!data) return;
      updateProgress(data);
      if (!data.running) {
        clearInterval(pollTimer);
        document.getElementById("startBtn").disabled = false;
        document.getElementById("stopBtn").classList.remove("visible");
        const ok   = (data.completed || []).length;
        const fail = (data.failed || []).length;
        const msg  = document.getElementById("completeMsg");
        msg.textContent = "Campaign complete! " + ok + " sent, " + fail + " failed.";
        msg.classList.add("visible");
      }
    });
  }, 1500);
}

function ins(tag) {
  const ta = document.getElementById("message");
  const s  = ta.selectionStart;
  const e  = ta.selectionEnd;
  ta.value = ta.value.slice(0, s) + tag + ta.value.slice(e);
  ta.selectionStart = ta.selectionEnd = s + tag.length;
  ta.focus();
}
