(function () {
  const path = window.location.pathname;

  // ── /email/thankyou — success, advance to next rep ───────────────────────
  if (/\/members\/\d+\/email\/thankyou/.test(path)) {
    chrome.runtime.sendMessage({ action: "formDone", success: true });
    return;
  }

  // ── /email/process — something went wrong, go back and retry same rep ────
  if (/\/members\/\d+\/email\/process/.test(path)) {
    chrome.runtime.sendMessage({ action: "retryRep" });
    return;
  }

  // ── /email — autofill form and wait for user to submit ───────────────────
  if (!/\/members\/\d+\/email$/.test(path)) return;

  chrome.runtime.sendMessage({ action: "pageReady" }, (response) => {
    if (!response || !response.rep || !response.userData) return;

    const { userData, rep } = response;

    // Rep name from page heading: "Email Rep. Smith, John Office"
    let repName = "Representative";
    const h1 = document.querySelector("h1");
    if (h1) {
      const m = h1.textContent.trim().match(/Email Rep\.\s+(.+?)\s+Office/i);
      if (m) {
        const fullName = m[1];
        const comma = fullName.indexOf(",");
        repName = comma > -1 ? fullName.slice(0, comma).trim() : fullName.trim();
      }
    }
    if (repName === "Representative" && rep.name) {
      const comma = rep.name.indexOf(",");
      repName = comma > -1 ? rep.name.slice(0, comma).trim() : rep.name.trim();
    }

    // Build personalised message
    const msg = userData.msgTemplate
      .split("[REP_NAME]").join(repName)
      .split("[FNAME]").join(userData.fname)
      .split("[LNAME]").join(userData.lname)
      .split("[EMAIL]").join(userData.email)
      .split("[PHONE]").join(userData.phone)
      .split("[ADDRESS]").join(userData.address)
      .split("[CITY]").join(userData.city)
      .split("[ZIP]").join(userData.zip);

    function sv(selectors, val) {
      selectors.forEach((s) => {
        const el = document.querySelector(s);
        if (el) {
          el.value = val;
          ["input", "change"].forEach((t) =>
            el.dispatchEvent(new Event(t, { bubbles: true }))
          );
        }
      });
    }
    function setSelect(sel, val) {
      const el = document.querySelector(sel);
      if (!el || !val) return;
      for (let i = 0; i < el.options.length; i++) {
        if (el.options[i].value === val || el.options[i].text === val) {
          el.selectedIndex = i;
          el.dispatchEvent(new Event("change", { bubbles: true }));
          return;
        }
      }
    }

    // Delay autofill 1.5s to let the page's own JS fully initialize all form
    // fields before we set values — prevents the /email/process validation error.
    setTimeout(() => {
      sv(['input[name="first_name"]', 'input[id*="first"]'],    userData.fname);
      sv(['input[name="last_name"]',  'input[id*="last"]'],     userData.lname);
      sv(['input[name="address"]'],                              userData.address);
      sv(['input[name="address2"]', 'input[name="address_2"]'], "");
      sv(['input[name="city"]'],                                 userData.city);
      sv(['input[name="state"]'],                                "TX");
      sv(['input[name="zip"]', 'input[name="zipcode"]'],        userData.zip);
      sv(['input[name="phone"]', 'input[type="tel"]'],          userData.phone);
      sv(['input[name="email"]', 'input[type="email"]'],        userData.email);
      sv(['input[name="subject"]'],                             userData.subject);
      sv(['textarea[name="message"]', "textarea"],              msg);
      setSelect('select[name="prefix"]', "");
      console.log('[TASSP] Fields filled after delay.');
    }, 3000);

    // Banner — show retry notice if this is a retry
    const isRetry = rep.retry === true;
    const banner = document.createElement("div");
    banner.innerHTML = `
      <span style="font-weight:600;color:#c9a84c;">TASSP</span>
      &nbsp;District ${rep.district} of 150 — ${repName}
      &nbsp;·&nbsp;
      <span style="color:${isRetry ? "#e2a84b" : "rgba(255,255,255,0.7)"};">
        ${isRetry ? "⚠ Retrying — review &amp; submit again." : "Form filled — review &amp; submit when ready."}
      </span>
    `;
    Object.assign(banner.style, {
      position: "fixed", bottom: "16px", right: "16px", zIndex: "999999",
      background: "#0d1b2a", border: `1px solid ${isRetry ? "rgba(226,168,75,0.7)" : "rgba(201,168,76,0.5)"}`,
      borderRadius: "6px", padding: "10px 16px", fontSize: "13px",
      color: "#f5f0e8", fontFamily: "system-ui, sans-serif",
      boxShadow: "0 4px 20px rgba(0,0,0,0.4)", maxWidth: "440px", lineHeight: "1.4",
    });
    document.body.appendChild(banner);

    console.log(`[TASSP] ${isRetry ? "Retry" : "Filled"} District ${rep.district} — ${repName}. Waiting for submit.`);
  });
})();
