# TASSP Mass Emailer — Chrome Extension

> A Chrome extension that auto-fills your contact information on every Texas House representative's email form, one district at a time. You review, you submit — the extension handles the rest.

---

## What It Does

The TASSP Mass Emailer helps advocates contact all 150 Texas House representatives during the 89th Legislature session. Instead of manually filling out the same form 150 times, the extension:

1. Opens each representative's email page automatically
2. Waits 3 seconds for the page to fully load
3. Fills in all your contact details and a personalised message
4. Waits for **you** to review and click Submit
5. Detects the confirmation page and automatically loads the next representative

The extension **never submits the form for you** — you stay in full control of every message sent.

---

## Installation

### Requirements
- Google Chrome browser
- Developer Mode enabled in Chrome

### Steps

1. **Download** the latest release zip from the [website](https://yourusername.github.io/tassp-emailer) or the Releases section of this repo

2. **Unzip** the downloaded file
   - Windows: Right-click → Extract All
   - Mac: Double-click the zip file
   - You will get a folder called `tassp-v6`

3. **Open Chrome Extensions**
   - Go to `chrome://extensions` in your browser
   - Or: Chrome menu (⋮) → More Tools → Extensions

4. **Enable Developer Mode**
   - Toggle the **Developer mode** switch in the top-right corner of the Extensions page

5. **Load the extension**
   - Click **Load unpacked**
   - Select the `tassp-v6` folder
   - The TASSP Emailer icon will appear in your Chrome toolbar

---

## How to Use

### First-Time Setup

1. Click the **TASSP Emailer** icon in your Chrome toolbar to open the popup
2. Fill in your personal contact information:
   - First and last name
   - Address, city, state, ZIP
   - Phone number and email
3. Write your message template in the message box
   - Use `[REP_NAME]` anywhere in the message — it will be replaced with each representative's last name automatically
   - Example: `Dear Representative [REP_NAME], I am writing to urge you to support...`
4. Enter your email subject
5. Click **Save** to store your information

### Running a Campaign

1. Click **Start Campaign** in the popup
2. The extension opens District 1's email page and fills the form after 3 seconds
3. A banner appears at the bottom-right of the page confirming the district and rep name
4. Review the filled form — edit anything if needed
5. Click **Send Message** on the form
6. The site loads a confirmation page — the extension detects it and automatically navigates to the next district
7. Repeat until all 150 districts are complete

### Stopping Mid-Campaign

Click **Stop** in the extension popup at any time. Your progress is saved — you can resume by manually navigating to where you left off and restarting.

---

## Message Template Tokens

| Token | Replaced With |
|-------|--------------|
| `[REP_NAME]` | Representative's last name (e.g. `Smith`) |
| `[FNAME]` | Your first name |
| `[LNAME]` | Your last name |
| `[EMAIL]` | Your email address |
| `[PHONE]` | Your phone number |
| `[ADDRESS]` | Your street address |
| `[CITY]` | Your city |
| `[ZIP]` | Your ZIP code |

---

## URL Flow

The extension monitors three URL patterns on `house.texas.gov`:

| URL | Action |
|-----|--------|
| `/members/*/email` | Autofills the form after 3-second delay |
| `/members/*/email/process` | Navigates back to the same rep's form to retry |
| `/members/*/email/thankyou` | Confirms success and loads the next district |

If `/email/process` appears after submitting (a validation error page), the extension automatically redirects back to the same representative's form so you can try again.

---

## District List

The extension covers all 150 Texas House districts for the 89th Legislature (2025–2026 session), Districts 1 through 150.

---

## Troubleshooting

**Form fields are not filling**
- Make sure the extension is enabled in `chrome://extensions`
- Refresh the page and try again — the 3-second delay should give the page enough time to initialize
- Check that you saved your contact info in the popup before starting

**Getting redirected to `/email/process`**
- This is a validation error from the site, not the extension
- The extension will automatically redirect you back to the same rep's form
- Double-check that all required fields in the popup are filled in (name, address, phone, email, subject, message)

**Extension not advancing to the next district**
- Make sure the campaign is still running (check the popup)
- The extension only advances when it detects the `/email/thankyou` confirmation URL
- If the site shows a different confirmation page, refresh and resubmit

**Banner not appearing**
- The extension content script may not have loaded — try refreshing the page
- Make sure you clicked Start Campaign in the popup before navigating to a rep's page

---

## File Structure

```
tassp-v6/
├── manifest.json      # Extension configuration and permissions
├── background.js      # Service worker — manages campaign state and navigation
├── content.js         # Injected into TX House pages — handles autofill and detection
├── popup.html         # Extension popup UI
├── popup.js           # Popup logic — save info, start/stop campaign
├── index.html         # GitHub Pages landing/download page
└── README.md          # This file
```

---

## Permissions

The extension requests the following Chrome permissions:

| Permission | Reason |
|------------|--------|
| `tabs` | Navigate between representative pages |
| `storage` | Save your contact info and campaign progress |
| `scripting` | Inject the autofill script into House pages |
| `host_permissions: house.texas.gov` | Only runs on Texas House website |

The extension does **not** collect, transmit, or store any data outside your browser.

---

## Privacy

- All your contact information is stored locally in Chrome's storage (`chrome.storage.local`)
- No data is sent to any server other than the Texas House website when you submit a form
- The extension only activates on `house.texas.gov` pages

---

## Contributing

This extension was built for TASSP advocacy during the 89th Texas Legislature. To report a bug or suggest an improvement, open an issue on this repository.

---

## Disclaimer

This tool is not affiliated with, endorsed by, or connected to the Texas House of Representatives or any government entity. It is an independent advocacy tool built to help constituents exercise their right to contact their elected representatives.

---

*TASSP Mass Emailer · v2.1 · 89th Texas Legislature*
